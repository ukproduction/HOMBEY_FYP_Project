﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Hombay.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult About()
        {
            return View("~/Views/Home/About.cshtml");
        }
        public ActionResult Contact()
        {
            return View("~/Views/Account/Contact.cshtml");
        }
        public ActionResult Projects()
        {
            return View("~/Views/Account/Projects.cshtml");
        }
        public ActionResult Services()
        {
            return View("~/Views/Account/Services.cshtml");
        }
        public ActionResult Project_Details()
        {
            return View("~/Views/Account/Project_Details.cshtml");
        }
        public ActionResult Platforms()
        {
            return View("~/Views/Account/Platforms.cshtml");
        }
        public ActionResult x()
        {
            return View("~/Views/Account/x.cshtml");
        }
        public ActionResult landowner_form()
        {
            return View("~/Views/Account/landowner_form.cshtml");
        }
        public ActionResult servicer_form()
        {
            return View("~/Views/Account/servicer_form.cshtml");
        }
        public ActionResult seller_form()
        {
            return View("~/Views/Account/seller_form.cshtml");
        }
        public ActionResult Products()
        {
            return View("~/Views/product/Products.cshtml");
        }
    }
}