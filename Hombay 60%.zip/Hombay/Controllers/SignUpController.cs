﻿using System;
using System.Collections.Generic;
using System.Data.Entity;

using System.Linq;
using System.Web;
using System.Web.Mvc;
using Hombay.models;
using Hombay.Models;

namespace Hombay.Controllers
{
    public class SignUpController : Controller
    {
        [HttpGet]
        public ActionResult AddorEdit(int id = 0)
        {
            SignUp usermodel = new SignUp();
            return View(usermodel);
            /*
            [HttpPost]
            public ActionResult AddorEdit(SignUp SignUpModel)
            {
                using (DbModels dbmodel = new DbModels())
                {
                    dbmodel.SignUp.Add(SignUpModel);
                    dbmodel.savechanges();
                }
                ModelState.Clear();

                return View("AddorEdit", new SignUp());
            }*/
        }
    }
}